import javafx.application.Application;

public class PuzzleMain {

	public static void main(String[] args) {
		Application.launch(PuzzleHome.class, args);
	}

}
